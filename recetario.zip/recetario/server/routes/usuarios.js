const express = require("express");
const db = require("../db");
const router = express.Router();

router.get("/:id", async (req, res) => {
  const id = req.params.id;
  try {
    const [rows] = await db.promise().query("SELECT id, nombre, email, fecha_registro FROM usuarios WHERE id = ?", [id]);
    if (!rows.length) return res.status(404).json({ error: "Usuario no encontrado" });

    // contar recetas del usuario
    const [[{ count }]] = await db.promise().query("SELECT COUNT(*) AS count FROM recetas WHERE id_usuario = ?", [id]);
    res.json({ user: rows[0], recetas_count: count });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al obtener usuario" });
  }
});

module.exports = router;
