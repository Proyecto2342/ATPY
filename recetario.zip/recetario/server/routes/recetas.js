const express = require("express");
const db = require("../db");
const jwt = require("jsonwebtoken");
const router = express.Router();
const JWT_SECRET = "q29xF8nv92!-P0aR3bZy7KL6#kPQ1x*L98d2@_Az";


// middleware simple para verificar token
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: "No autenticado" });
  const token = auth.split(" ")[1];
  try {
    const data = jwt.verify(token, JWT_SECRET);
    req.user = data;
    next();
  } catch {
    return res.status(401).json({ error: "Token inválido" });
  }
}

// Crear receta (requiere auth)
router.post("/", authMiddleware, async (req, res) => {
  const r = req.body;
  const sql = `
    INSERT INTO recetas
    (id_usuario, categoria, titulo, descripcion, ingredientes, procedimiento, portada, imgSec,
     acomp1_titulo, acomp1_texto, acomp2_titulo, acomp2_texto)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  try {
    const values = [
      req.user.id, r.categoria, r.titulo, r.descripcion,
      r.ingredientes, r.procedimiento, r.portada, r.imgSec,
      r.acomp1_titulo, r.acomp1_texto, r.acomp2_titulo, r.acomp2_texto
    ];
    const [result] = await db.promise().query(sql, values);
    res.json({ message: "Receta creada", id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al crear receta" });
  }
});

// Listar (opcional filtro por categoria y búsqueda)
router.get("/", async (req, res) => {
  const { categoria, q } = req.query;
  let sql = "SELECT r.*, u.nombre AS creador FROM recetas r JOIN usuarios u ON r.id_usuario = u.id";
  const params = [];
  if (categoria && categoria !== "todas") {
    sql += " WHERE r.categoria = ?";
    params.push(categoria);
  }
  if (q) {
    sql += params.length ? " AND " : " WHERE ";
    sql += " (r.titulo LIKE ? OR r.descripcion LIKE ?)";
    params.push(`%${q}%`, `%${q}%`);
  }
  sql += " ORDER BY fecha DESC";
  try {
    const [rows] = await db.promise().query(sql, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al listar recetas" });
  }
});

// Obtener detalle por id (incrementa vistas)
router.get("/:id", async (req, res) => {
  const id = req.params.id;
  try {
    const [rows] = await db.promise().query("SELECT r.*, u.nombre AS creador FROM recetas r JOIN usuarios u ON r.id_usuario = u.id WHERE r.id = ?", [id]);
    if (!rows.length) return res.status(404).json({ error: "Receta no encontrada" });

    // actualizar vistas
    await db.promise().query("UPDATE recetas SET vistas = vistas + 1 WHERE id = ?", [id]);
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al obtener receta" });
  }
});

// Like (requiere auth)
router.post("/:id/like", authMiddleware, async (req, res) => {
  const id = req.params.id;
  try {
    await db.promise().query("UPDATE recetas SET megusta = megusta + 1 WHERE id = ?", [id]);
    res.json({ message: "Like registrado" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error al dar like" });
  }
});

module.exports = router;
