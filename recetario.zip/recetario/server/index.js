import express from "express";
import cors from "cors";
import { db } from "./db.js";

const app = express();
app.use(cors());
app.use(express.json());




import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Servir carpeta PUBLIC
app.use(express.static(path.join(__dirname, "../public")));


// -----------------------------
// 📌 Obtener todas las recetas
// -----------------------------
app.get("/recetas", (req, res) => {
  db.query("SELECT * FROM recetas", (err, data) => {
    if (err) return res.json(err);
    return res.json(data);
  });
});

// ---------------------------------------------
// 📌 Agregar una nueva receta
// ---------------------------------------------
app.post("/recetas", (req, res) => {
  const { titulo, descripcion, categoria, portada } = req.body;

  const sql = "INSERT INTO recetas (titulo, descripcion, categoria, portada) VALUES (?, ?, ?, ?)";
  db.query(sql, [titulo, descripcion, categoria, portada], (err, result) => {
    if (err) return res.json(err);
    return res.json({ message: "Receta registrada", id: result.insertId });
  });
});

app.listen(3000, () => console.log("🟢 Backend en http://localhost:3000"));





