const express = require("express");
const cors = require("cors");
const path = require("path");

// rutas
const authRoutes = require("./routes/auth");
const recetasRoutes = require("./routes/recetas");
const usuariosRoutes = require("./routes/usuarios");

const app = express();

app.use(cors());
app.use(express.json({ limit: "30mb" })); // soporta base64 de imágenes
app.use(express.urlencoded({ extended: true }));

// servir carpeta pública (frontend) si la colocas en /public
app.use(express.static(path.join(__dirname, "../public")));

// rutas API
app.use("/api/auth", authRoutes);
app.use("/api/recetas", recetasRoutes);
app.use("/api/usuarios", usuariosRoutes);

// fallback para SPA
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor corriendo en http://localhost:${PORT}`));
