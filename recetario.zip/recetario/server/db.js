const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",      // cambia si usas contraseña
  database: "recetario"
});

db.connect(err => {
  if (err) console.error("Error MySQL:", err);
  else console.log("MySQL conectado ✔");
});

module.exports = db;
