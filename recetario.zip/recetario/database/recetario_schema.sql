-- Crear base de datos
CREATE DATABASE IF NOT EXISTS recetario CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE recetario;

-- Tabla usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla recetas
CREATE TABLE IF NOT EXISTS recetas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  categoria VARCHAR(50),
  titulo VARCHAR(150),
  descripcion TEXT,
  ingredientes TEXT,      -- coma-separated or newline
  procedimiento TEXT,     -- newline-separated
  portada LONGTEXT,       -- base64 or URL
  imgSec LONGTEXT,        -- base64 or URL
  acomp1_titulo VARCHAR(100),
  acomp1_texto TEXT,
  acomp2_titulo VARCHAR(100),
  acomp2_texto TEXT,
  vistas INT DEFAULT 0,
  megusta INT DEFAULT 0,
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Índices útiles
CREATE INDEX idx_recetas_categoria ON recetas(categoria);
CREATE INDEX idx_recetas_titulo ON recetas(titulo);
