async function convertirABase64(file) {
  return new Promise(resolve => {
    if (!file) return resolve(null);
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.readAsDataURL(file);
  });
}

document.getElementById("guardarReceta").addEventListener("click", async () => {

  const receta = {
    categoria: document.getElementById("categoriaReceta").value,
    titulo: document.getElementById("tituloReceta").value.trim(),
    descripcion: document.getElementById("descripcionBreve").value.trim(),
    ingredientes: document.getElementById("ingredientes1").value.trim(),
    procedimiento: document.getElementById("procedimiento1").value.trim(),
    ensalada: document.getElementById("ensalada").value.trim(),
    bebida: document.getElementById("bebida").value.trim(),
    portada: await convertirABase64(document.getElementById("imagenPortada").files[0]),
    imgSec: await convertirABase64(document.getElementById("imagenSecundaria").files[0])
  };

  const res = await fetch("http://localhost:3000/recetas", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(receta)
  });

  const data = await res.json();
  alert(data.message);

  window.location.href = "index.html";
});
