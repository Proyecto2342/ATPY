export default class Usuario {
  constructor({ id, nombre, email }) {
    this.id = id;
    this.nombre = nombre;
    this.email = email;
  }

  get info() {
    return `${this.nombre} (${this.email})`;
  }
}
