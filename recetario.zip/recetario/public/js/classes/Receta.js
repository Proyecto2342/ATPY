export default class Receta {
  constructor(data) {
    this.id = data.id;
    this.categoria = data.categoria;
    this.titulo = data.titulo;
    this.descripcion = data.descripcion;
    this.ingredientes = data.ingredientes;
    this.procedimiento = data.procedimiento;
    this.portada = data.portada;
    this.imgSec = data.imgSec;
    this.acomp1_titulo = data.acomp1_titulo;
    this.acomp1_texto = data.acomp1_texto;
    this.acomp2_titulo = data.acomp2_titulo;
    this.acomp2_texto = data.acomp2_texto;
    this.vistas = data.vistas;
    this.megusta = data.megusta;
    this.creador = data.creador;
  }

  get resumen() {
    return `${this.titulo} - ${this.descripcion?.substring(0, 50)}...`;
  }
}
