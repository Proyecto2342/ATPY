import Receta from "./Receta.js";

export default class RecetaFactory {
  static crear(data) {
    return new Receta({
      id: data.id,
      categoria: data.categoria,
      titulo: data.titulo,
      descripcion: data.descripcion,
      ingredientes: data.ingredientes?.split("\n") ?? [],
      procedimiento: data.procedimiento?.split("\n") ?? [],
      portada: data.portada,
      imgSec: data.imgSec,
      acomp1_titulo: data.acomp1_titulo,
      acomp1_texto: data.acomp1_texto,
      acomp2_titulo: data.acomp2_titulo,
      acomp2_texto: data.acomp2_texto,
      vistas: data.vistas,
      megusta: data.megusta,
      creador: data.creador
    });
  }
}
