import Usuario from "./Usuario.js";

export default class UsuarioFactory {
  static crear(data) {
    return new Usuario(data);
  }
}
