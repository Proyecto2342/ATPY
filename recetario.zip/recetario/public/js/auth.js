import api from "./api.js";

// Login
const btnLogin = document.getElementById("btnLogin");
if (btnLogin) {
  btnLogin.addEventListener("click", async () => {
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    const result = await api.post("/auth/login", { email, password });

    if (result.token) {
      localStorage.setItem("token", result.token);
      localStorage.setItem("user", JSON.stringify(result.user));
      window.location.href = "index.html";
    } else {
      alert(result.error || "Error al iniciar sesión");
    }
  });
}

// Registro
const btnRegister = document.getElementById("btnRegister");
if (btnRegister) {
  btnRegister.addEventListener("click", async () => {
    const nombre = document.getElementById("nombre").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    const result = await api.post("/auth/register", { nombre, email, password });

    if (result.message) {
      alert("Registrado con éxito");
      window.location.href = "login.html";
    } else {
      alert(result.error || "Error al registrar");
    }
  });
}
