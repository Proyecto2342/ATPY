import api from "./api.js";

// Convertir imagen a Base64
function toBase64(file) {
  return new Promise(res => {
    if (!file) return res(null);
    const reader = new FileReader();
    reader.onload = () => res(reader.result);
    reader.readAsDataURL(file);
  });
}

document.getElementById("btnGuardar").addEventListener("click", async () => {

  const portada = await toBase64(document.getElementById("portada").files[0]);
  const imgSec = await toBase64(document.getElementById("imgSec").files[0]);

  const data = {
    categoria: document.getElementById("categoria").value,
    titulo: document.getElementById("titulo").value,
    descripcion: document.getElementById("descripcion").value,
    ingredientes: document.getElementById("ingredientes").value,
    procedimiento: document.getElementById("procedimiento").value,
    portada,
    imgSec,
    acomp1_titulo: document.getElementById("acomp1_titulo").value,
    acomp1_texto: document.getElementById("acomp1_texto").value,
    acomp2_titulo: document.getElementById("acomp2_titulo").value,
    acomp2_texto: document.getElementById("acomp2_texto").value
  };

  const result = await api.post("/recetas", data);

  if (result.id) {
    alert("Receta registrada ✔");
    window.location.href = "index.html";
  } else {
    alert(result.error || "Error al guardar");
  }
});
