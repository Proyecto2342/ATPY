const API_URL = "http://localhost:3000/api";

export default {
  async get(path) {
    const token = localStorage.getItem("token");
    const res = await fetch(`${API_URL}${path}`, {
      headers: { "Authorization": `Bearer ${token}` }
    });
    return res.json();
  },

  async post(path, data) {
    const token = localStorage.getItem("token");
    const res = await fetch(`${API_URL}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": token ? `Bearer ${token}` : ""
      },
      body: JSON.stringify(data)
    });
    return res.json();
  }
};
