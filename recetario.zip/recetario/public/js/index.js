import api from "./api.js";
import RecetaFactory from "./classes/RecetaFactory.js";

const lista = document.getElementById("listaRecetas");
const buscar = document.getElementById("buscar");
const catBtns = document.querySelectorAll("[data-cat]");
const btnAdd = document.getElementById("btnAdd");

// Cargar recetas iniciales
cargarRecetas("todas");

// Filtrar por categoría
catBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelector(".active")?.classList.remove("active");
    btn.classList.add("active");

    const categoria = btn.getAttribute("data-cat");
    cargarRecetas(categoria);
  });
});

// Buscar
buscar.addEventListener("input", () => {
  const q = buscar.value.trim();
  cargarRecetas("todas", q);
});

// Ir a crear receta
btnAdd.addEventListener("click", () => {
  window.location.href = "registrar.html";
});


// ---- Función principal ----
async function cargarRecetas(categoria = "todas", q = "") {
  lista.innerHTML = "Cargando...";

  const query = `?categoria=${categoria}&q=${q}`;
  const recetasRaw = await api.get(`/recetas${query}`);

  lista.innerHTML = "";

  recetasRaw.forEach(raw => {
    const receta = RecetaFactory.crear(raw);

    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <img src="${receta.portada}">
      <h3>${receta.titulo}</h3>
      <p>${receta.descripcion}</p>
    `;

    card.addEventListener("click", () => {
      localStorage.setItem("receta_id", receta.id);
      window.location.href = "detalle.html";
    });

    lista.appendChild(card);
  });
}
