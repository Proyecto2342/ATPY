import api from "./api.js";

const user = JSON.parse(localStorage.getItem("user"));

async function cargarPerfil() {
  const data = await api.get(`/usuarios/${user.id}`);

  document.getElementById("nombre").textContent = data.user.nombre;
  document.getElementById("email").textContent = data.user.email;
  document.getElementById("total").textContent = data.recetas_count;
}

cargarPerfil();
