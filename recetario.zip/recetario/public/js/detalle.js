import api from "./api.js";

const id = localStorage.getItem("receta_id");

async function cargar() {
  const data = await api.get(`/recetas/${id}`);

  document.getElementById("portada").src = data.portada;
  document.getElementById("imgSec").src = data.imgSec;

  document.getElementById("titulo").textContent = data.titulo;
  document.getElementById("descripcion").textContent = data.descripcion;
  document.getElementById("creador").textContent = data.creador;
  document.getElementById("vistas").textContent = data.vistas;
  document.getElementById("likes").textContent = data.megusta;

  document.getElementById("ingredientes").innerHTML =
    data.ingredientes.split("\n").map(i => `<li>${i}</li>`).join("");

  document.getElementById("procedimiento").innerHTML =
    data.procedimiento.split("\n").map(p => `<li>${p}</li>`).join("");

  document.getElementById("acomp1").innerHTML = `
    <h3>${data.acomp1_titulo}</h3>
    <p>${data.acomp1_texto}</p>
  `;

  document.getElementById("acomp2").innerHTML = `
    <h3>${data.acomp2_titulo}</h3>
    <p>${data.acomp2_texto}</p>
  `;
}

document.getElementById("likeBtn").addEventListener("click", async () => {
  const result = await api.post(`/recetas/${id}/like`, {});
  if (result.message) cargar();
});

cargar();
