const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
app.use(cors());
app.use(express.json({ limit: "50mb" })); // permite imágenes base64

// ===============================
// 👉 RUTA PARA GUARDAR RECETAS
// ===============================
app.post("/recetas", (req, res) => {
  const r = req.body;

  const sql = `
    INSERT INTO recetas (categoria, titulo, descripcion, ingredientes, procedimiento, ensalada, bebida, portada, imgSec)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  db.query(sql, [
    r.categoria, r.titulo, r.descripcion, r.ingredientes,
    r.procedimiento, r.ensalada, r.bebida,
    r.portada, r.imgSec
  ], err => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Receta registrada correctamente" });
  });
});

// ===============================
// 👉 RUTA PARA LISTAR RECETAS
// ===============================
app.get("/recetas", (req, res) => {
  db.query("SELECT * FROM recetas", (err, rows) => {
    if (err) return res.status(500).json({ error: err });
    res.json(rows);
  });
});

// ===============================
// 👉 RUTA PARA VER UNA RECETA
// ===============================
app.get("/recetas/:id", (req, res) => {
  db.query("SELECT * FROM recetas WHERE id = ?", [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err });
    res.json(rows[0]);
  });
});

// Servidor
app.listen(3000, () => {
  console.log("Servidor iniciado en http://localhost:3000");
});
